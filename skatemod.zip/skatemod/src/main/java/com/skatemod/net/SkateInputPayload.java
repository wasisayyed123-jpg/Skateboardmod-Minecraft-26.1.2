package com.skatemod.net;

import com.skatemod.SkateMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Sent client -> server every tick while riding. The server is authoritative;
 * the client only reports what the player is pressing.
 */
public record SkateInputPayload(int throttle, int steer, int flags, int skin) implements CustomPacketPayload {
    public static final int FLAG_JUMP = 1;
    public static final int FLAG_KICKFLIP = 2;
    public static final int FLAG_HEELFLIP = 4;

    public static final SkateInputPayload IDLE = new SkateInputPayload(0, 0, 0, 1);
    public static final Type<SkateInputPayload> TYPE = new Type<>(SkateMod.id("input"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SkateInputPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SkateInputPayload::throttle,
            ByteBufCodecs.VAR_INT, SkateInputPayload::steer,
            ByteBufCodecs.VAR_INT, SkateInputPayload::flags,
            ByteBufCodecs.VAR_INT, SkateInputPayload::skin,
            SkateInputPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
