package com.skatemod.block;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A wooden ramp that rises toward its facing direction in four steps.
 * The skateboard reads the same height function, so visuals and physics match.
 */
public class WoodenRampBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<WoodenRampBlock> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            propertiesCodec(),
            Codec.DOUBLE.fieldOf("height").forGetter(b -> b.height)
    ).apply(instance, WoodenRampBlock::new));

    private final double height; // peak height in blocks
    private final VoxelShape[] shapes = new VoxelShape[4];

    public WoodenRampBlock(BlockBehaviour.Properties properties, double height) {
        super(properties);
        this.height = height;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
        for (Direction d : Direction.Plane.HORIZONTAL) {
            shapes[d.get2DDataValue()] = buildShape(d);
        }
    }

    public double getHeight() {
        return height;
    }

    /** Surface height above the block floor at progress u (0 = low edge, 1 = high edge). */
    public double heightAt(double u) {
        int step = Mth.clamp((int) (u * 4), 0, 3);
        return (step + 1) * height / 4.0;
    }

    /** Converts a position inside the block (0..1 per axis) to progress u along the ramp. */
    public double localU(Direction facing, double lx, double lz) {
        return switch (facing) {
            case SOUTH -> lz;
            case NORTH -> 1.0 - lz;
            case EAST -> lx;
            default -> 1.0 - lx;
        };
    }

    private VoxelShape buildShape(Direction d) {
        VoxelShape shape = Shapes.empty();
        double stepTop = height * 4.0; // pixels per step (16 px = 1 block)
        for (int i = 0; i < 4; i++) {
            double u0 = i * 4.0;
            double u1 = 16.0;
            double top = (i + 1) * stepTop;
            double x0, x1, z0, z1;
            switch (d) {
                case SOUTH -> { x0 = 0; x1 = 16; z0 = u0; z1 = u1; }
                case NORTH -> { x0 = 0; x1 = 16; z0 = 16 - u1; z1 = 16 - u0; }
                case EAST -> { x0 = u0; x1 = u1; z0 = 0; z1 = 16; }
                default -> { x0 = 16 - u1; x1 = 16 - u0; z0 = 0; z1 = 16; }
            }
            shape = Shapes.or(shape, Block.box(x0, 0, z0, x1, top, z1));
        }
        return shape;
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapes[state.getValue(FACING).get2DDataValue()];
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapes[state.getValue(FACING).get2DDataValue()];
    }
}
