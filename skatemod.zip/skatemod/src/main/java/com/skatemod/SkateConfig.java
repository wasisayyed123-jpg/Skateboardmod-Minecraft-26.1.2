package com.skatemod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** Settings shared by client and server, stored in config/skatemod.json. */
public class SkateConfig {
    public static final int SKIN_COUNT = 34;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("skatemod.json");
    private static SkateConfig instance;

    public int selectedSkin = 1;               // 1..34
    public double speedMultiplier = 1.0;       // 0.5..2.0
    public double ollieHeight = 1.0;           // 0.5..2.0
    public double wheelSpinMultiplier = 1.0;   // 0..3, visual only
    public boolean showTrickMessages = true;

    public static SkateConfig get() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static void load() {
        SkateConfig loaded = null;
        try {
            if (Files.exists(FILE)) {
                loaded = GSON.fromJson(Files.readString(FILE), SkateConfig.class);
            }
        } catch (IOException | RuntimeException e) {
            System.err.println("[skatemod] Could not read config, using defaults: " + e.getMessage());
        }
        instance = loaded != null ? loaded : new SkateConfig();
        instance.selectedSkin = (int) clamp(instance.selectedSkin, 1, SKIN_COUNT);
        instance.speedMultiplier = clamp(instance.speedMultiplier, 0.5, 2.0);
        instance.ollieHeight = clamp(instance.ollieHeight, 0.5, 2.0);
        instance.wheelSpinMultiplier = clamp(instance.wheelSpinMultiplier, 0.0, 3.0);
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(get()));
        } catch (IOException e) {
            System.err.println("[skatemod] Could not save config: " + e.getMessage());
        }
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
