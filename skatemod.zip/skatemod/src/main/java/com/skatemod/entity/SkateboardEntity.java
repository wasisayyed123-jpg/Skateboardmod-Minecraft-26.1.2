package com.skatemod.entity;

import com.skatemod.SkateConfig;
import com.skatemod.block.WoodenRampBlock;
import com.skatemod.net.SkateInputPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Skateboard with simple server-authoritative physics: acceleration, friction, braking,
 * steering, ollies, ramp launches, air spins, kickflips/heelflips and a trick score on landing.
 */
public class SkateboardEntity extends Entity {
    private static final EntityDataAccessor<Float> WHEEL_ANGLE =
            SynchedEntityData.defineId(SkateboardEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> FLIP_ANGLE =
            SynchedEntityData.defineId(SkateboardEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(SkateboardEntity.class, EntityDataSerializers.INT);

    private static final double GRAVITY = 0.08;
    private static final double OLLIE_VELOCITY = 0.42;
    private static final double BASE_MAX_SPEED = 0.35;
    private static final double ACCEL = 0.012;
    private static final double FRICTION = 0.993;
    private static final double BRAKE = 0.90;
    private static final double AIR_DRAG = 0.999;
    private static final float TURN_RATE = 3.0F;
    private static final float SPIN_RATE = 12.0F;
    private static final float FLIP_RATE = 18.0F;
    private static final double STEP_UP = 0.6;

    private double speed;
    private double vy;
    private boolean airborne;
    private boolean ollied;
    private boolean prevJump;
    private int airTicks;
    private float spinTotal;
    private float flipTotal;
    private float flipAngle;
    private int flipSign = 1;
    private double lastRampHeight;
    private double foundRampHeight;
    private int score;
    private SkateInputPayload input = SkateInputPayload.IDLE;

    public SkateboardEntity(EntityType<SkateboardEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(WHEEL_ANGLE, 0.0F).define(FLIP_ANGLE, 0.0F).define(SKIN, 1);
    }

    // ---- public API used by networking and rendering ----

    public void setInput(SkateInputPayload payload) {
        this.input = payload;
        setSkin(payload.skin());
    }

    public void setSkin(int skin) {
        entityData.set(SKIN, Mth.clamp(skin, 1, SkateConfig.SKIN_COUNT));
    }

    public int getSkin() {
        return entityData.get(SKIN);
    }

    public float getWheelAngle() {
        return entityData.get(WHEEL_ANGLE);
    }

    public float getFlipAngle() {
        return entityData.get(FLIP_ANGLE);
    }

    // ---- riding ----

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!level().isClientSide() && getPassengers().isEmpty()) {
            player.startRiding(this);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().isEmpty();
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        callback.accept(passenger, getX(), getY() + 0.25, getZ());
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    /** The server owns the physics, so the client should not push its own position. */
    @Override
    public boolean isControlledByLocalInstance() {
        return false;
    }

    // ---- physics ----

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) {
            return;
        }

        SkateConfig cfg = SkateConfig.get();
        Entity rider = getFirstPassenger();
        SkateInputPayload in = rider instanceof Player ? input : SkateInputPayload.IDLE;

        boolean jumpDown = (in.flags() & SkateInputPayload.FLAG_JUMP) != 0;
        boolean jumpPressed = jumpDown && !prevJump;
        prevJump = jumpDown;

        if (!airborne) {
            if (jumpPressed) {
                takeOff(OLLIE_VELOCITY * cfg.ollieHeight, true);
            } else {
                groundMove(in, cfg);
            }
        }
        if (airborne) {
            airMove(in, cfg, rider);
        }

        entityData.set(WHEEL_ANGLE, (float) ((entityData.get(WHEEL_ANGLE) + speed * 458.0) % 360.0));
    }

    private void groundMove(SkateInputPayload in, SkateConfig cfg) {
        double mult = cfg.speedMultiplier;
        double maxSpeed = BASE_MAX_SPEED * mult;

        if (in.throttle() != 0) {
            speed += in.throttle() * ACCEL * mult;
        }
        if (in.throttle() < 0 && speed > 0) {
            speed *= BRAKE;
        } else {
            speed *= FRICTION;
        }
        speed = Mth.clamp(speed, -maxSpeed * 0.5, maxSpeed);

        if (in.steer() != 0 && Math.abs(speed) > 0.005) {
            float turn = (float) (in.steer() * TURN_RATE * Math.min(1.0, Math.abs(speed) / 0.1) * Math.signum(speed));
            setYRot(getYRot() + turn);
        }

        double yaw = Math.toRadians(getYRot());
        double nx = getX() - Math.sin(yaw) * speed;
        double nz = getZ() + Math.cos(yaw) * speed;

        if (isBlocked(nx, nz)) {
            speed = 0;
            nx = getX();
            nz = getZ();
        }

        double surface = groundHeightAt(nx, getY() + 0.5, nz);
        if (surface - getY() > STEP_UP) { // wall or too steep: stop
            speed = 0;
            nx = getX();
            nz = getZ();
            surface = groundHeightAt(nx, getY() + 0.5, nz);
        }

        if (surface < getY() - 0.1) { // rolled off an edge or a ramp top
            takeOff(Math.max(0, speed) * lastRampHeight * 1.15, false);
            lastRampHeight = 0;
            setPos(nx, getY(), nz);
            return;
        }

        if (foundRampHeight > 0) {
            lastRampHeight = foundRampHeight;
        }
        setPos(nx, surface, nz);
    }

    private void airMove(SkateInputPayload in, SkateConfig cfg, Entity rider) {
        airTicks++;

        if (in.steer() != 0) {
            float spin = in.steer() * SPIN_RATE;
            setYRot(getYRot() + spin);
            spinTotal += Math.abs(spin);
        }
        if ((in.flags() & SkateInputPayload.FLAG_KICKFLIP) != 0) {
            flipSign = 1;
            applyFlip(FLIP_RATE);
        } else if ((in.flags() & SkateInputPayload.FLAG_HEELFLIP) != 0) {
            flipSign = -1;
            applyFlip(-FLIP_RATE);
        }

        vy -= GRAVITY;
        speed *= AIR_DRAG;

        double yaw = Math.toRadians(getYRot());
        double nx = getX() - Math.sin(yaw) * speed;
        double nz = getZ() + Math.cos(yaw) * speed;
        if (isBlocked(nx, nz)) {
            speed *= -0.2;
            nx = getX();
            nz = getZ();
        }

        double ny = getY() + vy;
        double surface = groundHeightAt(nx, Math.max(getY(), ny) + 0.5, nz);
        if (vy <= 0 && ny <= surface) {
            landed(rider, cfg);
            setPos(nx, surface, nz);
            return;
        }
        setPos(nx, ny, nz);
    }

    private void takeOff(double velocity, boolean fromOllie) {
        airborne = true;
        vy = velocity;
        ollied = fromOllie;
        airTicks = 0;
        spinTotal = 0;
        flipTotal = 0;
    }

    private void applyFlip(float delta) {
        flipAngle = (flipAngle + delta) % 360.0F;
        if (flipAngle < 0) {
            flipAngle += 360.0F;
        }
        flipTotal += Math.abs(delta);
        entityData.set(FLIP_ANGLE, flipAngle);
    }

    private void landed(Entity rider, SkateConfig cfg) {
        airborne = false;
        vy = 0;
        if (airTicks >= 4) {
            String trick = trickName();
            int points = (int) (100 + airTicks * 5 + spinTotal * 0.5 + flipTotal * 0.5);
            score += points;
            if (rider instanceof Player player && cfg.showTrickMessages) {
                player.displayClientMessage(
                        Component.literal(trick + "! +" + points + "  (total " + score + ")"), true);
            }
        }
        spinTotal = 0;
        flipTotal = 0;
        airTicks = 0;
        flipAngle = 0;
        entityData.set(FLIP_ANGLE, 0.0F);
    }

    private String trickName() {
        String spin = spinTotal >= 900 ? "900 "
                : spinTotal >= 720 ? "720 "
                : spinTotal >= 540 ? "540 "
                : spinTotal >= 360 ? "360 "
                : spinTotal >= 180 ? "180 " : "";
        String base = flipTotal >= 300 ? (flipSign > 0 ? "Kickflip" : "Heelflip")
                : (ollied ? "Ollie" : "Air");
        return spin + base;
    }

    /**
     * Height of the walkable surface under (x, y, z), searching a few blocks down.
     * Ramps report their stepped surface and set foundRampHeight so launches can use it.
     */
    private double groundHeightAt(double x, double y, double z) {
        foundRampHeight = 0;
        BlockPos pos = BlockPos.containing(x, y, z);
        for (int i = 0; i < 6; i++, pos = pos.below()) {
            BlockState state = level().getBlockState(pos);
            if (state.getBlock() instanceof WoodenRampBlock ramp) {
                Direction facing = state.getValue(WoodenRampBlock.FACING);
                double u = ramp.localU(facing, x - pos.getX(), z - pos.getZ());
                foundRampHeight = ramp.getHeight();
                return pos.getY() + ramp.heightAt(u);
            }
            VoxelShape shape = state.getCollisionShape(level(), pos);
            if (!shape.isEmpty()) {
                return pos.getY() + shape.max(Direction.Axis.Y);
            }
        }
        return Double.NEGATIVE_INFINITY;
    }

    private boolean isBlocked(double x, double z) {
        BlockPos pos = BlockPos.containing(x, getY() + 0.4, z);
        BlockState state = level().getBlockState(pos);
        if (state.getBlock() instanceof WoodenRampBlock) {
            return false;
        }
        VoxelShape shape = state.getCollisionShape(level(), pos);
        return !shape.isEmpty() && pos.getY() + shape.max(Direction.Axis.Y) > getY() + STEP_UP;
    }

    // ---- save / load ----

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setSkin(tag.getInt("Skin"));
        score = tag.getInt("Score");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Skin", getSkin());
        tag.putInt("Score", score);
    }
}
