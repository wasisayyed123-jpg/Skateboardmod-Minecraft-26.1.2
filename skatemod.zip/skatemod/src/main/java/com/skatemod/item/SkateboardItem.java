package com.skatemod.item;

import com.skatemod.SkateMod;
import com.skatemod.entity.SkateboardEntity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class SkateboardItem extends Item {
    public SkateboardItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        Vec3 pos = context.getClickLocation();
        SkateboardEntity board = new SkateboardEntity(SkateMod.SKATEBOARD, level);
        board.setPos(pos.x, pos.y + 0.05, pos.z);
        board.setYRot(context.getPlayer() != null ? context.getPlayer().getYRot() : 0.0F);
        level.addFreshEntity(board);
        if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
