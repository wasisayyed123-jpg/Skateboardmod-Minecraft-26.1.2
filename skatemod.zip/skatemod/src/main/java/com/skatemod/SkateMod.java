package com.skatemod;

import com.skatemod.block.WoodenRampBlock;
import com.skatemod.entity.SkateboardEntity;
import com.skatemod.item.SkateboardItem;
import com.skatemod.net.SkateInputPayload;
import java.util.function.Function;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativemode.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class SkateMod implements ModInitializer {
    public static final String MOD_ID = "skatemod";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    public static final ResourceKey<EntityType<?>> SKATEBOARD_ENTITY_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, id("skateboard"));

    public static final EntityType<SkateboardEntity> SKATEBOARD = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            SKATEBOARD_ENTITY_KEY,
            EntityType.Builder.of(SkateboardEntity::new, MobCategory.MISC)
                    .sized(0.8F, 0.2F)
                    .clientTrackingRange(8)
                    .build(SKATEBOARD_ENTITY_KEY));

    public static final Item SKATEBOARD_ITEM = registerItem("skateboard", SkateboardItem::new);
    public static final Block WOODEN_RAMP_SMALL = registerRamp("wooden_ramp_small", 0.5);
    public static final Block WOODEN_RAMP_BIG = registerRamp("wooden_ramp_big", 1.0);

    private static Item registerItem(String name, Function<Item.Properties, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(new Item.Properties().setId(key)));
    }

    private static Block registerRamp(String name, double height) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id(name));
        Block block = Registry.register(BuiltInRegistries.BLOCK, blockKey,
                new WoodenRampBlock(BlockBehaviour.Properties.of()
                        .setId(blockKey)
                        .strength(2.0F)
                        .sound(SoundType.WOOD)
                        .noOcclusion(), height));
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id(name));
        Registry.register(BuiltInRegistries.ITEM, itemKey, new BlockItem(block, new Item.Properties().setId(itemKey)));
        return block;
    }

    @Override
    public void onInitialize() {
        SkateConfig.load();

        PayloadTypeRegistry.serverboundPlay().register(SkateInputPayload.TYPE, SkateInputPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SkateInputPayload.TYPE, (payload, context) -> {
            if (context.player().getVehicle() instanceof SkateboardEntity board) {
                board.setInput(payload);
            }
        });

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(SKATEBOARD_ITEM);
            entries.accept(WOODEN_RAMP_SMALL);
            entries.accept(WOODEN_RAMP_BIG);
        });
    }
}
