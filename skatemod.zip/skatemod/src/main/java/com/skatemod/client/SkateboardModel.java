package com.skatemod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.skatemod.SkateMod;
import net.minecraft.client.model.geom.LayerDefinition;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.texture.OverlayTexture;

/** Deck, two trucks, and four wheels. Wheels spin around their axles. */
public class SkateboardModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(SkateMod.id("skateboard"), "main");

    private final ModelPart root;
    private final ModelPart wheelFL;
    private final ModelPart wheelFR;
    private final ModelPart wheelBL;
    private final ModelPart wheelBR;

    public SkateboardModel(ModelPart root) {
        this.root = root;
        this.wheelFL = root.getChild("wheel_fl");
        this.wheelFR = root.getChild("wheel_fr");
        this.wheelBL = root.getChild("wheel_bl");
        this.wheelBR = root.getChild("wheel_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("deck",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3F, -3F, -10F, 6F, 1F, 20F),
                PartPose.offset(0F, 24F, 0F));
        root.addOrReplaceChild("truck_front",
                CubeListBuilder.create().texOffs(0, 22).addBox(-3.5F, -2F, -1F, 7F, 1F, 2F),
                PartPose.offset(0F, 24F, -7F));
        root.addOrReplaceChild("truck_back",
                CubeListBuilder.create().texOffs(0, 22).addBox(-3.5F, -2F, -1F, 7F, 1F, 2F),
                PartPose.offset(0F, 24F, 7F));

        root.addOrReplaceChild("wheel_fl", wheel(), PartPose.offset(-4F, 22F, -7F));
        root.addOrReplaceChild("wheel_fr", wheel(), PartPose.offset(4F, 22F, -7F));
        root.addOrReplaceChild("wheel_bl", wheel(), PartPose.offset(-4F, 22F, 7F));
        root.addOrReplaceChild("wheel_br", wheel(), PartPose.offset(4F, 22F, 7F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    private static CubeListBuilder wheel() {
        return CubeListBuilder.create().texOffs(24, 0).addBox(-0.5F, -2F, -2F, 1F, 4F, 4F);
    }

    /** Rotates all four wheels to the given angle in degrees. */
    public void animate(float wheelDegrees) {
        float rad = (float) Math.toRadians(wheelDegrees);
        wheelFL.xRot = rad;
        wheelFR.xRot = rad;
        wheelBL.xRot = rad;
        wheelBR.xRot = rad;
    }

    public void render(PoseStack pose, VertexConsumer consumer, int light) {
        root.render(pose, consumer, light, OverlayTexture.NO_OVERLAY);
    }
}
