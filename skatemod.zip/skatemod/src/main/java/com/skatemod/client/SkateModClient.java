package com.skatemod.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.skatemod.SkateConfig;
import com.skatemod.SkateMod;
import com.skatemod.entity.SkateboardEntity;
import com.skatemod.net.SkateInputPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.events.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;

public class SkateModClient implements ClientModInitializer {
    public static final KeyMapping SKIN_KEY = new KeyMapping(
            "key.skatemod.skins", InputConstants.Type.KEYSYM, InputConstants.KEY_G, KeyMapping.Category.MISC);
    public static final KeyMapping KICKFLIP_KEY = new KeyMapping(
            "key.skatemod.kickflip", InputConstants.Type.KEYSYM, InputConstants.KEY_Z, KeyMapping.Category.MISC);
    public static final KeyMapping HEELFLIP_KEY = new KeyMapping(
            "key.skatemod.heelflip", InputConstants.Type.KEYSYM, InputConstants.KEY_X, KeyMapping.Category.MISC);

    @Override
    public void onInitializeClient() {
        KeyBindingHelper.registerKeyBinding(SKIN_KEY);
        KeyBindingHelper.registerKeyBinding(KICKFLIP_KEY);
        KeyBindingHelper.registerKeyBinding(HEELFLIP_KEY);

        EntityModelLayerRegistry.registerModelLayer(SkateboardModel.LAYER, SkateboardModel::createBodyLayer);
        EntityRendererRegistry.register(SkateMod.SKATEBOARD, SkateboardRenderer::new);

        ClientTickEvents.END_CLIENT_TICK.register(SkateModClient::onClientTick);
    }

    private static void onClientTick(Minecraft mc) {
        while (SKIN_KEY.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new SkinSelectScreen(null));
            }
        }

        if (mc.player == null || !(mc.player.getVehicle() instanceof SkateboardEntity)) {
            return;
        }

        Options options = mc.options;
        int throttle = (options.keyUp.isDown() ? 1 : 0) - (options.keyDown.isDown() ? 1 : 0);
        int steer = (options.keyRight.isDown() ? 1 : 0) - (options.keyLeft.isDown() ? 1 : 0);
        int flags = (options.keyJump.isDown() ? SkateInputPayload.FLAG_JUMP : 0)
                | (KICKFLIP_KEY.isDown() ? SkateInputPayload.FLAG_KICKFLIP : 0)
                | (HEELFLIP_KEY.isDown() ? SkateInputPayload.FLAG_HEELFLIP : 0);

        ClientPlayNetworking.send(new SkateInputPayload(throttle, steer, flags, SkateConfig.get().selectedSkin));
    }
}
