package com.skatemod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.skatemod.SkateConfig;
import com.skatemod.SkateMod;
import com.skatemod.entity.SkateboardEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class SkateboardRenderer extends EntityRenderer<SkateboardEntity> {
    private final SkateboardModel model;

    public SkateboardRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new SkateboardModel(context.bakeLayer(SkateboardModel.LAYER));
        this.shadowRadius = 0.3F;
    }

    @Override
    public void render(SkateboardEntity board, float entityYaw, float partialTick,
                       PoseStack pose, MultiBufferSource buffers, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - Mth.lerp(partialTick, board.yRotO, board.getYRot())));
        pose.mulPose(Axis.ZP.rotationDegrees(board.getFlipAngle())); // kickflip / heelflip roll
        pose.scale(-1.0F, -1.0F, 1.0F);
        pose.translate(0.0F, -1.5F, 0.0F);

        float spin = board.getWheelAngle() * (float) SkateConfig.get().wheelSpinMultiplier;
        model.animate(spin);

        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(board)));
        model.render(pose, consumer, light);
        pose.popPose();

        super.render(board, entityYaw, partialTick, pose, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(SkateboardEntity board) {
        return SkateMod.id("textures/entity/skateboard/skin_" + String.format("%02d", board.getSkin()) + ".png");
    }
}
