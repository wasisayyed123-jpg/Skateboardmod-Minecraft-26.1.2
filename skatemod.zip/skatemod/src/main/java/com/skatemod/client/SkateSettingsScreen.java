package com.skatemod.client;

import com.skatemod.SkateConfig;
import java.util.function.DoubleConsumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Settings opened from Mod Menu. */
public class SkateSettingsScreen extends Screen {
    private final Screen parent;

    public SkateSettingsScreen(Screen parent) {
        super(Component.literal("Skate Mod Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        SkateConfig cfg = SkateConfig.get();
        int x = width / 2 - 110;
        int y = 40;

        addRenderableWidget(new Slider(x, y, 220, 20, "Speed", 0.5, 2.0,
                cfg.speedMultiplier, v -> cfg.speedMultiplier = v));
        addRenderableWidget(new Slider(x, y + 26, 220, 20, "Ollie height", 0.5, 2.0,
                cfg.ollieHeight, v -> cfg.ollieHeight = v));
        addRenderableWidget(new Slider(x, y + 52, 220, 20, "Wheel spin", 0.0, 3.0,
                cfg.wheelSpinMultiplier, v -> cfg.wheelSpinMultiplier = v));
        addRenderableWidget(Button.builder(trickLabel(cfg.showTrickMessages), b -> {
            cfg.showTrickMessages = !cfg.showTrickMessages;
            b.setMessage(trickLabel(cfg.showTrickMessages));
        }).bounds(x, y + 78, 220, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Choose skin (G)"),
                b -> minecraft.setScreen(new SkinSelectScreen(this)))
                .bounds(x, y + 104, 220, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(x, y + 140, 220, 20).build());
    }

    private static Component trickLabel(boolean on) {
        return Component.literal("Trick messages: " + (on ? "On" : "Off"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(font, title, width / 2, 16, 0xFFFFFF);
        g.drawCenteredString(font,
                "W/S drive  A/D steer or spin in air  Space ollie  Z kickflip  X heelflip",
                width / 2, height - 22, 0xAAAAAA);
    }

    @Override
    public void onClose() {
        SkateConfig.save();
        minecraft.setScreen(parent);
    }

    private static final class Slider extends AbstractSliderButton {
        private final String label;
        private final double min;
        private final double max;
        private final DoubleConsumer setter;

        Slider(int x, int y, int w, int h, String label, double min, double max,
               double current, DoubleConsumer setter) {
            super(x, y, w, h, Component.empty(), (current - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            updateMessage();
        }

        private double current() {
            return min + value * (max - min);
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label + ": " + String.format("%.2f", current())));
        }

        @Override
        protected void applyValue() {
            setter.accept(current());
        }
    }
}
