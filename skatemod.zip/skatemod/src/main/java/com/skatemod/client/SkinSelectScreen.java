package com.skatemod.client;

import com.skatemod.SkateConfig;
import java.awt.Color;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Grid of all 34 skins. Click one to select it. Opens with G. */
public class SkinSelectScreen extends Screen {
    private static final int COLUMNS = 6;
    private static final int CELL = 40;
    private static final int SWATCH = 32;

    private final Screen parent;
    private int gridX;
    private int gridY;

    public SkinSelectScreen(Screen parent) {
        super(Component.literal("Skateboard Skins"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int rows = (SkateConfig.SKIN_COUNT + COLUMNS - 1) / COLUMNS;
        gridX = width / 2 - (COLUMNS * CELL) / 2;
        gridY = 36;
        int bottom = gridY + rows * CELL;
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(width / 2 - 50, Math.min(bottom + 16, height - 28), 100, 20)
                .build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);

        int selected = SkateConfig.get().selectedSkin;
        for (int i = 0; i < SkateConfig.SKIN_COUNT; i++) {
            int cellX = gridX + (i % COLUMNS) * CELL;
            int cellY = gridY + (i / COLUMNS) * CELL;
            int x = cellX + (CELL - SWATCH) / 2;
            int y = cellY + (CELL - SWATCH) / 2;
            boolean hovered = mouseX >= x && mouseX < x + SWATCH && mouseY >= y && mouseY < y + SWATCH;

            if (i + 1 == selected) {
                g.fill(x - 3, y - 3, x + SWATCH + 3, y + SWATCH + 3, 0xFFFFD700);
            } else if (hovered) {
                g.fill(x - 2, y - 2, x + SWATCH + 2, y + SWATCH + 2, 0xFFFFFFFF);
            }
            g.fill(x, y, x + SWATCH, y + SWATCH, 0xFF000000 | swatchColor(i + 1));
            g.drawCenteredString(font, String.valueOf(i + 1), x + SWATCH / 2, y + SWATCH / 2 - 4, 0xFFFFFFFF);
        }

        g.drawCenteredString(font, "Selected: Skin " + selected, width / 2, gridY + 6 * CELL + 2, 0xFFFFD700);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int index = skinAt(mouseX, mouseY);
        if (index >= 0) {
            SkateConfig.get().selectedSkin = index + 1;
            SkateConfig.save();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private int skinAt(double mouseX, double mouseY) {
        for (int i = 0; i < SkateConfig.SKIN_COUNT; i++) {
            int cellX = gridX + (i % COLUMNS) * CELL;
            int cellY = gridY + (i / COLUMNS) * CELL;
            if (mouseX >= cellX && mouseX < cellX + CELL && mouseY >= cellY && mouseY < cellY + CELL) {
                return i;
            }
        }
        return -1;
    }

    /** Matches the main colour generated for each skin in tools/generate_skins.py. */
    private static int swatchColor(int skin) {
        float hue = (float) (((skin - 1) * 0.618034) % 1.0);
        return Color.HSBtoRGB(hue, 0.70F, 0.90F) & 0xFFFFFF;
    }

    @Override
    public void onClose() {
        SkateConfig.save();
        minecraft.setScreen(parent);
    }
}
