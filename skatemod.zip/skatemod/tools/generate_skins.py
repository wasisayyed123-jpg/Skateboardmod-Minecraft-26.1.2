#!/usr/bin/env python3
"""
Generates the 34 skateboard skins, the item icon, and the ramp models/blockstates.
No third-party dependencies. Run once from the project root:

    python3 tools/generate_skins.py
"""
import colorsys
import json
import os
import struct
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "skatemod")
SKIN_COUNT = 34


def write_png(path, width, height, rows):
    """rows: list of rows, each a list of (r, g, b, a) tuples."""
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n"
                + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9))
                + chunk(b"IEND", b""))


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def palette(skin):
    """Golden-ratio hue spacing keeps every skin distinct. Index: 0 base, 1 main, 2 accent, 3 near-black."""
    hue = ((skin - 1) * 0.618034) % 1.0

    def rgb(h, s, v):
        r, g, b = colorsys.hsv_to_rgb(h, s, v)
        return (round(r * 255), round(g * 255), round(b * 255), 255)

    return [
        rgb(hue, 0.18, 0.96),                # pale base
        rgb(hue, 0.70, 0.90),                # main shape colour
        rgb((hue + 0.5) % 1.0, 0.75, 0.95),  # complementary accent
        rgb(0.0, 0.0, 0.14),                 # near-black
    ]


def pattern(kind, x, y):
    """Palette index for pixel (x, y) on a 64x64 skin. Bauhaus-style geometric shapes."""
    if kind == 0:  # checker blocks
        return 1 if ((x // 8) + (y // 8)) % 2 else 0
    if kind == 1:  # bold accent stripes
        return 2 if (x // 8) % 2 else 0
    if kind == 2:  # concentric rings
        d = ((x - 32) ** 2 + (y - 32) ** 2) ** 0.5
        return 1 if int(d // 6) % 2 else 0
    if kind == 3:  # diagonal bands
        return 1 if ((x + y) // 6) % 2 else 0
    if kind == 4:  # arches (rounded tops on rectangles)
        u, v = x % 16, y % 16
        inside = (v >= 8 and 2 <= u <= 13) or ((u - 8) ** 2 + (v - 8) ** 2 <= 49 and v < 8)
        return 1 if inside else 0
    if kind == 5:  # polka dots
        u, v = x % 10 - 5, y % 10 - 5
        return 2 if u * u + v * v <= 6 else 0
    if kind == 6:  # quarter tiles
        return 1 if (x % 16 < 8) != (y % 16 < 8) else 0
    if kind == 7:  # dark vertical bars
        return 3 if x % 12 < 4 else 0
    return 0


def render_skin(skin, size=64):
    pal = palette(skin)
    kind = (skin - 1) % 8
    variant = (skin - 1) // 8  # mirrors the layout so the same shape reads differently
    rows = []
    for y in range(size):
        row = []
        for x in range(size):
            sx = size - 1 - x if variant in (1, 3) else x
            sy = size - 1 - y if variant in (2, 3) else y
            row.append(pal[pattern(kind, sx, sy)])
        rows.append(row)
    return rows


def item_icon(skin):
    pal = palette(skin)
    kind = (skin - 1) % 8
    return [[pal[pattern(kind, x * 4 + 2, y * 4 + 2)] for x in range(16)] for y in range(16)]


def ramp_model(height):
    """Stepped wedge matching WoodenRampBlock: facing = south (high edge at +z)."""
    faces = {d: {"uv": [0, 0, 16, 16], "texture": "#all"}
             for d in ("north", "south", "east", "west", "up", "down")}
    elements = []
    for i in range(4):
        top = (i + 1) * height * 4
        elements.append({"from": [0, 0, 4 * i], "to": [16, top, 16], "faces": faces})
    return {
        "parent": "minecraft:block/block",
        "textures": {"all": "minecraft:block/spruce_planks", "particle": "minecraft:block/spruce_planks"},
        "elements": elements,
    }


def blockstate(name):
    # Minecraft y-rotation is clockwise seen from above: south=0, west=90, north=180, east=270.
    rotations = {"south": 0, "west": 90, "north": 180, "east": 270}
    variants = {}
    for facing, y in rotations.items():
        entry = {"model": f"skatemod:block/{name}"}
        if y:
            entry["y"] = y
        variants[f"facing={facing}"] = entry
    return {"variants": variants}


def item_definition(model):
    return {"model": {"type": "minecraft:model", "model": model}}


def main():
    for skin in range(1, SKIN_COUNT + 1):
        write_png(os.path.join(ASSETS, "textures", "entity", "skateboard", f"skin_{skin:02d}.png"),
                  64, 64, render_skin(skin))

    write_png(os.path.join(ASSETS, "textures", "item", "skateboard.png"), 16, 16, item_icon(1))
    write_json(os.path.join(ASSETS, "models", "item", "skateboard.json"),
               {"parent": "minecraft:item/generated", "textures": {"layer0": "skatemod:item/skateboard"}})
    write_json(os.path.join(ASSETS, "items", "skateboard.json"), item_definition("skatemod:item/skateboard"))

    for name, height in (("wooden_ramp_small", 0.5), ("wooden_ramp_big", 1.0)):
        write_json(os.path.join(ASSETS, "blockstates", f"{name}.json"), blockstate(name))
        write_json(os.path.join(ASSETS, "models", "block", f"{name}.json"), ramp_model(height))
        write_json(os.path.join(ASSETS, "models", "item", f"{name}.json"),
                   {"parent": f"skatemod:block/{name}"})
        write_json(os.path.join(ASSETS, "items", f"{name}.json"),
                   item_definition(f"skatemod:item/{name}"))

    print(f"Generated {SKIN_COUNT} skins and block/item models in {os.path.normpath(ASSETS)}")


if __name__ == "__main__":
    main()
